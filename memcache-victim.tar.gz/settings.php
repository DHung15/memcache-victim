<?php
session_start();
if (!isset($_SESSION['loggedin'])) {
    header('Location: index.php');
    exit();
}

$memcached = new Memcached();
$memcached->addServer('127.0.0.1', 11211);

// Lấy thông tin admin từ Memcached
$adminUser = $memcached->get('admin_username');
$adminPass = $memcached->get('admin_password');
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Settings</title>
</head>
<body>
    <h1>Cài đặt tài khoản</h1>
    <form method="POST" action="">
        <label for="admin_user">Tài khoản Admin:</label>
        <input type="text" id="admin_user" name="admin_user" value="<?php echo $adminUser; ?>" readonly><br><br>

        <label for="admin_pass">Mật khẩu Admin:</label>
        <input type="password" id="admin_pass" name="admin_pass" value="<?php echo $adminPass; ?>" readonly><br><br>

        <button type="button" onclick="togglePassword()">Hiển thị mật khẩu</button>
    </form>

    <script>
        function togglePassword() {
            var passField = document.getElementById("admin_pass");
            if (passField.type === "password") {
                passField.type = "text";
            } else {
                passField.type = "password";
            }
        }
    </script>
</body>
</html>

