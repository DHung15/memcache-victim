<?php
session_start();
if (!isset($_SESSION['loggedin'])) {
    header('Location: index.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
</head>
<body>
    <h1>Chào mừng đến với Dashboard</h1>
    <nav>
        <a href="settings.php">Settings</a> |
        <a href="index.php">Đăng xuất</a>
    </nav>
</body>
</html>

